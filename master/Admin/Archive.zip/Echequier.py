import random
import numpy as np


class Echequier:

    # C'est les interactions directes avec le plateau de jeu
    def __init__(self, array):
        self.array = array
        # self.array = np.array([0,1,2,3,4,5,6,7])
        # self.array = np.array([6,2,0,2,0,5,1,1])
        # self.array = np.array([6,4,2,0,5,7,1,3])
        # self.array = np.array([4,7,3,0,6,1,5,2])
        # self.array = np.array([1,2,5,6,4,7,1,3])

    def __str__(self):
        ech = np.array(
            [[0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0],
             [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0]])
        for i in range(len(self.array)):
            ech[self.array[i], i] = "1"
        return str(ech)

    def changementAlea(self):
        nv = self.array.copy()
        nv[random.randint(0, 7)] = random.randint(0, 7)
        return nv
