class Etat:
    def __init__(self, ech):
        self.ech = ech

    def Heuristique(self):
        heuri = 0
        e = self.ech.array
        for i in range(len(e)):
            for j in range(i + 1, len(e)):
                x1 = i
                y1 = e[i]
                x2 = j
                y2 = e[j]
                if y1 == y2:
                    heuri += 1
                elif abs(x1 - x2) == abs(y1 - y2):
                    heuri += 1
                elif x1 == x2:
                    heuri += 1
        return heuri
