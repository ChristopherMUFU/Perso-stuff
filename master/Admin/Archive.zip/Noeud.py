class Noeud:
    def __init__(self, etat):
        self.etat = etat

    def __copy__(self):
        return self