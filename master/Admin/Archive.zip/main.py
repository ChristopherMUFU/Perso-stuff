from Echequier import Echequier
from Etat import Etat
from Noeud import Noeud
import time
import numpy as np


def Jouer(n):
    if n.etat.Heuristique() == 0:
        print(n.etat.ech)
    else:
        o = n.etat.ech.changementAlea()
        ech2 = Echequier(o)
        etat2 = Etat(ech2)
        nouveau = Noeud(etat2)

        print(n.etat.Heuristique(), nouveau.etat.Heuristique())
        if n.etat.Heuristique() < nouveau.etat.Heuristique():
            print("PREMIER")
            res = Noeud(n.etat)
            Jouer(res)
        else:
            print("DEUXIEME")
            res = Noeud(nouveau.etat)
            Jouer(res)


if __name__ == '__main__':
    # self.array = np.array([6,2,0,2,0,5,1,1])
    # self.array = np.array([6,4,2,0,5,7,1,3])
    # self.array = np.array([4,7,3,0,6,1,5,2])
    # self.array = np.array([1,2,5,6,4,7,1,3])
    ech = Echequier(np.array([6, 2, 0, 2, 0, 5, 1, 1]))
    et = Etat(ech)
    n = Noeud(et)
    Jouer(n)
